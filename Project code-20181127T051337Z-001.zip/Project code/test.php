<?php
echo"
<html>
<body>
<h2>welcome</h2>
</body>
</html>";




?>
