<html>
<body>
<form>

<input type="radio" name="a" value="b" onclick="window.open('adminlogin.html')" /> Admin
<input type="radio" name="a" value="b" onclick="window.open('ev.html')" /> Evaluator
</form>
</body>

</html>
